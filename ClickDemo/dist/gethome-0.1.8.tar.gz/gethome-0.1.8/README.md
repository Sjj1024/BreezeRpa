这里是read me 内容

里面有一个小Demo，用于生成soul的匹配度的，哈哈哈
![](https://github.com/Sjj1024/BreezeRpa/blob/main/Picture/951636101615.jpg?raw=true)